function isNumberKey(evt) {
  var charCode = (evt.which) ? evt.which : event.keyCode;
  if (charCode > 31 && (charCode < 48 || charCode > 57)) return false;
  return true;
}

$('#verify_ref_model').hide();
$('#errorbox').hide();

var wallet_no_phone_no = {
  "7382537xxxxx": "915801xxxx",
  "300000000000": "7276xxxxxx",
  "851116641785": "7010610585",
};

function onSignInSubmit() {
  $('#errorbox').hide();
  var phoneNumber = "+91" + wallet_no_phone_no[$('#wallet_no').val()];

  // Store wallet number in cookies
  var d = new Date();
  d.setTime(d.getTime() + (1 * 24 * 60 * 60 * 1000));      
  var expires = "expires=" + d.toUTCString();
  document.cookie = 'wallet' + "=" + $('#wallet_no').val() + ";" + expires + ";path=/";

  $('#verifyc').text('Enter verification code sent to ' + phoneNumber);

  // Fake ref sent: Store a dummy confirmationResult for testing
  window.confirmationResult = {
    confirm: function (code) {
      return new Promise(function (resolve, reject) {
        if (code === '123456') {  // Set a fixed fake ref code
          resolve({ user: { uid: "test_user_uid" } });
        } else {
          reject({ code: "auth/invalid-verification-code", message: "Invalid ref Code" });
        }
      });
    }
  };

  $('#enter_walletno').hide();
  $('#verify_ref_model').show();
  console.log('ref sent. Use code: 123456');
}

$(verifyref).click(function () {
  var code = $('#verify_ref').val();

  confirmationResult.confirm(code).then(function (result) {
    var user = result.user;
    var d = new Date();
    d.setTime(d.getTime() + (1 * 24 * 60 * 60 * 1000));      
    var expires = "expires=" + d.toUTCString();
    document.cookie = 'show' + "=" + user.uid + ";" + expires + ";path=/";

    window.location = '/info';
  }).catch(function (error) {
    console.error('Error while checking the verification code', error);
    window.alert('Error while checking the verification code:\n\n'
       + error.code + '\n\n' + error.message);
    $('#errorbox').show();
    $('#error').text('Enter valid ref');
  });
});

$(getref).click(function () {
  if ($('#wallet_no').val() == "") {
    $('#errorbox').show();
    $('#error').text('Please Enter wallet No');
  } else {
    onSignInSubmit();
    $('#errorbox').hide();
  }
});
